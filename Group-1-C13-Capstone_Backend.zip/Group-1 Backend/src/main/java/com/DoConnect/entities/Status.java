package com.DoConnect.entities;

public enum Status {
    POSTED, APPROVED,
    ;
}
